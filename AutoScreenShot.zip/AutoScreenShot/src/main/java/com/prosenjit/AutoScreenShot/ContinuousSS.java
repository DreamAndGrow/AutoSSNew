package com.prosenjit.AutoScreenShot;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;


public class ContinuousSS extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private JButton startButton;
    private JButton stopButton;
    private Timer timer;
    private Robot robot;
    private int delay = 2000; // Delay between each screenshot in milliseconds
    String foldername;
    InsertPicturesToWord insertPic;
    int i;
    
    public ContinuousSS() {
        setTitle("Continuous Screenshot Taker (Powered by VAM Test Team)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 100);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel();
        GridLayout grid=new GridLayout(2, 3);      
        grid.setHgap(5); // Set horizontal gap between cells
        grid.setVgap(5); // Set vertical gap between cells
        panel.setLayout(grid);
        JLabel lbl=new JLabel("Frequency(sec)");
        
        JLabel lb2=new JLabel("NOT RUNNING");
        JLabel lb1=new JLabel("*Numbers Only");
  
        
        JTextField inp=new JTextField();
//        inp.setBounds(120,50,500,100);
        startButton = new JButton("Start");
//        startButton.setBounds(100,200,100,20);
        stopButton = new JButton("Stop");
//        stopButton.setBounds(200,200,100,20);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                	i=1;
                    // Create a Robot instance to capture the screen
                    robot = new Robot();
                    //define folder name
                    foldername=System.getProperty("user.dir")+"\\Screenshots";
                    //Create Folder if not exisits
                    if(!new File(foldername).exists())
                    	new File(foldername).mkdirs();
                    
                    delay= (int) (Float.parseFloat(inp.getText())*1000);
                    lb2.setText("RUNNING");
                    // Create a Timer to capture screenshots at regular intervals
                    timer = new Timer(delay, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                // Capture the screen
                                BufferedImage screenshot = robot.createScreenCapture(
                                        new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

                                // Save the screenshot to a file
                                ImageIO.write(screenshot, "png", new java.io.File(foldername+"\\"+System.currentTimeMillis()+".png"));

                                System.out.println("Screenshot taken!");
                                
                                i++;
                                if(i==5000) {
                                	timer.stop();
                                    System.out.println("Screenshot capture stopped!");
                                    lb2.setText("NOT RUNNING");
                                }
                                	
                            } catch (Exception ex) {
//                                ex.printStackTrace();
                            	JOptionPane.showMessageDialog(null, "Exception occurred in taking Screenshot. Please Reach out to VAM NFT Team/Prosenjit", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    });

                    timer.start();
                    System.out.println("Screenshot capture started!");
                } catch (NumberFormatException ex) {
                    //System.out.println("Array Index Out Of Bounds Exception: " + ex.getMessage());
                	JOptionPane.showMessageDialog(null, "Please input whole number only", "Error", JOptionPane.ERROR_MESSAGE);
                }
                catch (AWTException ex) {
                	JOptionPane.showMessageDialog(null, "Exception occurred in Frame. Please Reach out to VAM NFT Team/Prosenjit", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timer != null && timer.isRunning()) {
                    timer.stop();
                    System.out.println("Screenshot capture stopped!");
                    lb2.setText("NOT RUNNING");
                    insertPic=new InsertPicturesToWord();
                }
                else
                	JOptionPane.showMessageDialog(null, "Start the application first", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        panel.add(lbl);
        panel.add(inp);
        panel.add(lb1);
        panel.add(startButton);
        panel.add(stopButton);
        panel.add(lb2);

        add(panel);
        
//        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ContinuousSS();
                
                
                Toolkit toolkit =  Toolkit.getDefaultToolkit ();
                Dimension dim = toolkit.getScreenSize();
                System.out.println("Width of Screen Size is "+dim.width+" pixels");
                System.out.println("Height of Screen Size is "+dim.height+" pixels");       
                int resolution =Toolkit.getDefaultToolkit().getScreenResolution();
                System.out.println(resolution);
            }
        });
    }
}
