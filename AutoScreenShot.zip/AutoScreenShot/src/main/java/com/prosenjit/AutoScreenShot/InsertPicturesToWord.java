package com.prosenjit.AutoScreenShot;

import org.apache.poi.util.IOUtils;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.*;
import java.io.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import javax.swing.JOptionPane;

public class InsertPicturesToWord {

	public InsertPicturesToWord() {
    	// Path to the folder containing the pictures
        String imagePath = System.getProperty("user.dir")+"\\Screenshots"; 
        // Path for the output Word document
        String wordPath = System.getProperty("user.dir")+"\\"+System.currentTimeMillis()+".docx"; 

        try {
            // Create a new Word document
            @SuppressWarnings("resource")
			XWPFDocument document = new XWPFDocument();

            // Get a list of picture files from the folder
            File folder = new File(imagePath);
            List<File> pictureFiles = Arrays.asList(folder.listFiles((dir, name) -> name.endsWith(".png")));
            
            // Sort the list based on file names
            pictureFiles.sort(Comparator.comparing(File::getName));

            // Iterate over each picture file and insert it into the document
            for (File pictureFile : pictureFiles) {
                // Create a new paragraph
                XWPFParagraph paragraph = document.createParagraph();
                XWPFRun run = paragraph.createRun();

                // Read the picture file into a byte array
                InputStream pictureStream = new FileInputStream(pictureFile);
                byte[] pictureBytes = IOUtils.toByteArray(pictureStream);
                pictureStream.close();

                // Add the picture to the run
                int format = XWPFDocument.PICTURE_TYPE_JPEG; // Change the format as per your image type
                run.addPicture(new ByteArrayInputStream(pictureBytes), format, pictureFile.getName(), Units.toEMU(451), Units.toEMU(254));
                
                System.out.println("Pictures inserted successfully.");
            }

            // Save the document to the specified output path
            FileOutputStream out = new FileOutputStream(wordPath);
            document.write(out);
            out.close();
            System.out.println("Word FIle saved successfully.");
            
            //Delete the screenshot folder now
            File ssFolder = new File(imagePath);

            if (ssFolder.exists()) {
                deleteFolder(ssFolder);
                System.out.println("SS Folder deleted successfully.");
            } else {
                System.out.println("SS Folder does not exist.");
            }
            
            JOptionPane.showMessageDialog(null, "Word File Generated with all the screenshots", "Information", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
//            e.printStackTrace();
        	JOptionPane.showMessageDialog(null, "Exception occurred while inserting pictures to word file. Please Reach out to VAM NFT Team/Prosenjit", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
	
	private static void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteFolder(file);
                } else {
                    file.delete();
                }
            }
        }
        folder.delete();
    }
}

